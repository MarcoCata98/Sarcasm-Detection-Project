Results of the participatin systems
